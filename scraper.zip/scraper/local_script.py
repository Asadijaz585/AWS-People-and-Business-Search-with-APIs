import os
cmd = 'scp -i galaxy_key.pem input_file.csv ubuntu@ec2-34-203-242-176.compute-1.amazonaws.com:~'
cmd1 = 'ssh -i "galaxy_key.pem" ubuntu@ec2-34-203-242-176.compute-1.amazonaws.com'
os.system(cmd)
print('connecting ec2 instance fo further process')
os.system(cmd1)